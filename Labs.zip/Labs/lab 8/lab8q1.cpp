#include <iostream>
#include <string.h>
#include<pthread.h>

using namespace std;


void *calaverage(void* p)
{

int* ar2=(int*)p;
float *avg= new float();
float temp=0;
int i=0;
for(;ar2[i]!=-1;i++)
{

temp=temp+ar2[i];
}

temp=temp/i;
*avg=temp;
pthread_exit(avg);



}
void *calmin(void* p)
{

int* ar2=(int*)p;
int *min= new int();
int temp=ar2[0];;
int i=0;
for(;ar2[i]!=-1;i++)
{
if(temp>ar2[i]){
temp=ar2[i];
}
}

*min=temp;
pthread_exit(min);



}
void *calmax(void* p)
{

int* ar2=(int*)p;
int *max= new int();
int temp=ar2[0];;
int i=0;
for(;ar2[i]!=-1;i++)
{
if(temp<ar2[i]){
temp=ar2[i];
}
}

*max=temp;
pthread_exit(max);



}

int main(int argc,char *argv[])
{




  int NoOfElements=argc-1;
  int *arr=new int[NoOfElements];
  int i=0;
  for(int j=1;j<=NoOfElements;j++)
  {
  int a=atoi(argv[j]);
  arr[i++]=a;
  
  }
  arr[i]=-1;
  pthread_t id,id2,id3;
  cout<<"Your List of numbers is : "<<endl;
   for(int ii=0;arr[ii]!=-1;ii++)
  {

cout<<arr[ii]<<" ";
  
  }
  cout<<endl;
  arr[i]=-1;
  void * k;
 pthread_create(&id, NULL,&calaverage,(void*)arr);
  pthread_join(id,&k);
  float k1=*(float*)k;
cout<<"Average of list is = "<<k1<<endl;
 pthread_create(&id2, NULL,&calmin,(void*)arr);
  pthread_join(id2,&k);
   int k2=*(int*)k;
cout<<"Minimum no in the list is = "<<k2<<endl;
   pthread_create(&id3, NULL,&calmax,(void*)arr);
  pthread_join(id3,&k);
  k2=*(int*)k;
cout<<"Maximum no in the list is = "<<k2<<endl;
  
  return 0;
}
