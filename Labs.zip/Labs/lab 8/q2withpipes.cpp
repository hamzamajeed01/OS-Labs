#include<iostream>
#include <sys/wait.h>
#include <unistd.h>
using namespace std;
int main()
{
 
  
   int n1;
    int fd1[2];
        int fd2[2];
            int fd3[2];
             int fd4[2];
            double result=0;
   double O1=0;
   double O2=0;
   char operation;
   

   pipe(fd1);
    pipe(fd2);
     pipe(fd3);
     pipe(fd4);
     cout<<"Enter operand 1 :"<<endl;
     cin>>O1;
        cout<<"Enter operand 2 :"<<endl;
     cin>>O2;
        cout<<"Enter Operation :"<<endl;
     cin>>operation;
 n1=fork();
  if(n1==0){ 
   read(fd1[0],&O1, sizeof(O1));
      read(fd2[0],&O2, sizeof(O2));
         read(fd3[0],&operation, sizeof(operation));
     if(operation=='+')
     {
     result=O1+O2;
     }
     else if(operation=='-')
     {
     result=O1-O2;
     }
       else if(operation=='*')
     {
     result=O1*O2;
     }
       else if(operation=='/')
     {
     result=O1/O2;
     }
     else{
     
     cout<<"Invalid operation type"<<endl;
     exit(0);
     }
    write(fd1[1],&result, sizeof(result));
        exit(0);
    }
  if(n1>0) {
 
 write(fd1[1],&O1, sizeof(O1));
      write(fd2[1],&O2, sizeof(O2));
         write(fd3[1],&operation, sizeof(operation));
        wait(NULL);
        read(fd1[0],&result, sizeof(result));
     cout<<O1<<" "<<operation<<" " <<O2<<" = "<<result<<endl;
      
    }
 

   
}
