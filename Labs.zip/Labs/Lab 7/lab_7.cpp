#include <iostream>
#include <string.h>
#include<pthread.h>

using namespace std;
int a;
int *arr=new int[100];

void *fibonacciGenerator(void* p)
{


int n2=1;
int n3=0; 
int n1=0;

 
 int k=2;
 arr[0]=0;
 arr[1]=1;  
 for(int i=2;;++i)  
 { 
// cout<<"output for " <<a<<" : ";   
  n3=n1+n2;    
 // cout<<n3<<" ";   
    arr[k++]=n3;  
  n1=n2;    
  n2=n3;
  
  if(n3>=a)
  {
  break;
  } 
 } 
  arr[k++]=-1;  
pthread_exit(arr);



}


int main(int argc,char *argv[])
{




  int NoOfElements=argc-1;
  pthread_t id[NoOfElements];
  int *output;
for (int i=0;i<NoOfElements;i++){
a=atoi(argv[i+1]);
 pthread_create(&id[i], NULL,&fibonacciGenerator,NULL);
  pthread_join(id[i],(void**)&output);
for(int l=0;arr[l]!=-1;l++)
{
cout<<output[l]<<" ";
} 
cout<<endl;
  }

  
  
}
