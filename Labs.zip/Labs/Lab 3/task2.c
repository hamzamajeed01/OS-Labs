#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
int main()
{
int count =0;
int pid=fork();
if(pid==0)
{

FILE * fp;
fp=fopen("fork.txt","r");
char str[100];
while(!feof(fp))
{
fgets(str,100,fp);

for(int j=0; str[j]!='\0';j++)
{
if((str[j]>=48 && str[j]<=57) ||(str[j]>=65 && str[j]<=90)|| (str[j]>=97 && str[j]<=122) || str[j]==32)
{
}
else {
printf("%c ",str[j]);
count++;
}
}
}
fclose(fp);
printf(" No of special characters are = %d",count);
exit(0);
}
if(pid>0)
{

wait(NULL);
printf("\nProgram completed \n");

}

return 0;
}
