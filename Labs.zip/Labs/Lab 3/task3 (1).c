#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
int main()
{
//int x=execlp("mkdir","mkdir","LabTestFolder",NULL);
//int x1=execlp("touch","touch","LabTestFolder/test1.txt",NULL);
//int y3=execlp("touch","touch","LabTestFolder/test2.txt",NULL);
//int y=execlp("ls","ls","-all",NULL);
//int x=execlp("rm","rm","LabTestFolder/test1.txt",NULL);
//int x=execlp("rm","rm","LabTestFolder/test2.txt",NULL);
//int x=execlp("rmdir","rmdir","LabTestFolder",NULL);
return 0;
}
