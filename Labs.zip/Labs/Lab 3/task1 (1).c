#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
int main()
{
const int n=10;
int arr[n];
printf("Enter values in the array: \n");
for(int i=0;i<n;i++)
{
scanf("%d",&arr[i]);
}
int pid=fork();

if(pid==0)
{

for(int i=0;i<n;i++)
	{		
		for(int j=i+1;j<n;j++)
		{
			if(arr[i]>arr[j])
			{
			int temp=0;
				temp  =arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	
	printf("I am child 1 : ");
	for(int i=0;i<n;i++)
	printf("%d ",arr[i]);
	printf("\n \n");
	exit(0);
}


if(pid>0)
{
wait(NULL);
pid=fork();
if(pid==0)
{

for(int i=0;i<n;i++)
	{		
		for(int j=i+1;j<n;j++)
		{
			if(arr[i]<arr[j])
			{
			int temp=0;
				temp  =arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	
	printf("I am child 2 : ");
	for(int i=0;i<n;i++)
	printf("%d ",arr[i]);
	printf("\n \n");
	exit(0);


}
if(pid>0){
wait(NULL);
printf("parent process terminated\n");
}

}


return 0;
}
