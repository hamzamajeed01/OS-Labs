#include<iostream>
#include <sys/wait.h>
#include <unistd.h>
#include<string>
using namespace std;
 
int main()
{
 
   char arr[]="my name is hamza";
   int n1;
    int fd1[2];
   pipe(fd1);
 n1=fork();
  if(n1==0){ 
        read(fd1[0],arr,sizeof(arr));
      cout<<arr<<endl;
        
        for(int i=0; i<sizeof(arr);i++)
        {

        if((arr[i]>='A' && arr[i]<='Z') || (arr[i]>='a' && arr[i]<='z'))
	{
		if(arr[i]>='A' && arr[i]<='Z')
			arr[i]=arr[i]+32;
		else if(arr[i]>='a' && arr[i]<='z')
			arr[i]=arr[i]-32;
		
				
	}
	}
        close(fd1[0]);
         write(fd1[1],arr,sizeof(arr));
        close(fd1[1]);
        exit(0);
    }
  if(n1>0) {
        write(fd1[1], arr, sizeof(arr));
        close(fd1[1]);
        wait(NULL);
       read(fd1[0],arr,sizeof(arr));
        cout<<"String after conversion is : "<<arr<<endl;
        close(fd1[0]);
      
    }
 

   
}
