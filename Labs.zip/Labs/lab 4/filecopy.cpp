#include<iostream>
#include <sys/wait.h>
#include <unistd.h>
#include<string>
#include<fstream>
using namespace std;
 
int main(int argc,char * argv[])
{
 
int fd[2];
pipe(fd);
int n1=fork();
if(n1==0)
{
string s;
close(fd[1]);
read(fd[0],argv[1],sizeof(argv[1]));
read(fd[0],argv[2],sizeof(argv[2]));
close(fd[0]);
ifstream file;
ofstream file1;
file1.open(argv[2]);
file.open(argv[1]);
while(!file.eof())
{
getline(file,s);
file1<<s;
}
file.close();
file1.close();
close(fd[0]);
exit(0);
}
else{

close(fd[0]);
write(fd[1],argv[1],sizeof(argv[1]));
write(fd[1],argv[2],sizeof(argv[2]));
close(fd[1]);
wait(NULL);



}
   return 0;
}
