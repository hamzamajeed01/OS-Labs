#include<iostream>
#include <sys/wait.h>
#include <unistd.h>
using namespace std;
 
int main()
{
 
   int arr[5]={1,7,8,1,2};
   int n1;
    int fd1[2];
   int fd2[2]; 
   int sum=0;
   
   pipe(fd1);
   pipe(fd2);
 n1=fork();
  if(n1==0){
        close(fd1[1]);  
        read(fd1[0],arr,sizeof(arr));
        for (int i=0;i<5;i++)
        sum=sum+arr[i];
        close(fd1[0]);
        close(fd2[0]);
        write(fd2[1], &sum,sizeof(sum));
        close(fd2[1]);
        exit(0);
    }
  if(n1>0) {
  close(fd1[0]);
        write(fd1[1], arr, sizeof(arr));
        close(fd1[1]);
        wait(NULL);
        close(fd2[1]);
        read(fd2[0], &sum, sizeof(sum));
          close(fd2[0]);
        cout<<"Sum is = : "<<sum<<endl;
      
    }
 

   
}
