#include  <stdio.h>
#include  <stdlib.h>
#include<string.h>
#include  <sys/types.h>
#include  <sys/ipc.h>
#include<sys/wait.h>
#include  <sys/shm.h>
#include<string.h>
int main(int  argc, char *argv[])
{
     char    ShmID;
     char    *ShmPTR;
      char str[1000];
     int pid_t;
     int    status;
 
     printf("Process is about to fork a child process...\n");
     int pid = fork();
     if (pid < 0) {
          printf("*** fork error ***\n");
          exit(1);
     }
     else if (pid == 0) {
     
     int key=shmget(12321, 1024, 0 ); 
     ShmPTR = (char *) shmat(key, NULL, 0);
      FILE * fptr;
   fptr = fopen(argv[1], "r");
	int k=0;
	while (!feof(fptr)) {
	fgets(str, sizeof(str), fptr);
	for(int i=0;i<sizeof(str);i++)
	{
	ShmPTR[k++]=str[i];
	}
	}
	ShmPTR[k++]='\0';
	fclose(fptr);
     printf("Child has read data from file into shared memory. and data is ..%s \n",
          ShmPTR );
          int tr=sizeof(ShmPTR);
          printf("gg %d.\n",tr);
          exit(0);
     }
else{


ShmID=shmget(12321, 1024, IPC_CREAT | IPC_EXCL | 0666);
    
     if (ShmID < 0) {
          printf("*** shmget error ***\n");
          exit(1);
     }
     printf("Process has created a shared memory...\n");

     ShmPTR = (char *) shmat(ShmID, NULL, 0);
   
     printf("Process has attached the shared memory to char array ShmPTR...\n");

     wait(&status);
   char stre[1000];
          strcpy(str,ShmPTR);
        int i=0;
        int g=0;
     while(i<sizeof(ShmPTR))
    {
     if(ShmPTR[i]>=0 && ShmPTR[i]<=9){
     i++;
     
     }
       
        if(ShmPTR[i]>='a' && ShmPTR[i]<='z')
        {
            int ascii = ShmPTR[i];
            ascii = ascii-32;
            stre[g] = ascii;
        }
        else{
            stre[g] = ShmPTR[i];
            }
        i++;
        g++;
    }
     FILE * fptr2;
   fptr2 = fopen(argv[1], "w");
     fputs(stre, fptr2);
     printf("Server has detected the completion of its child...\n");
      printf("Child has read data from file into shared memory. and data is ..%s \n",
          ShmPTR );
     shmdt((void *) ShmPTR);
     printf("Server has detached its shared memory...\n");
     shmctl(ShmID, IPC_RMID, NULL);
     printf("Server has removed its shared memory...\n");
     printf("Server exits...\n");
     exit(0);
     }
     return 0;
}
