#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

sem_t sem1, sem2;
void *thread2(void *arg)
{
    while(1)
    {
        sem_wait(&sem2);
        printf("b");
        sem_post(&sem1);
    }
}

void *thread1(void *arg)
{
    while(1)
    {
        sem_wait(&sem1);
        printf("a");
        sem_post(&sem2);
    }
}



void *thread3(void *arg)
{
    while(1)
    {
        sem_wait(&sem1);
        printf("c");
        sem_post(&sem2);
    }
}

int main()
{
    pthread_t id1, id2, id3;
    sem_init(&sem1, 0, 1);
    sem_init(&sem2, 0, 0);
    pthread_create(&id1, NULL, thread1, NULL);
    pthread_create(&id2, NULL, thread2, NULL);
    pthread_create(&id3, NULL, thread3, NULL);
    pthread_join(id1, NULL);
    pthread_join(id2, NULL);
    pthread_join(id3, NULL);
    sem_destroy(&sem1);
    sem_destroy(&sem2);
    return 0;
}


