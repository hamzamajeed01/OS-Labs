#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define N 8
pthread_mutex_t mutex;
char buffer[N];
sem_t sem1, sem2;

void *consumer(void *arg)
{
    int i;
    for (i = 0; i < N; i++)
    {
        sem_wait(&sem2);
        pthread_mutex_lock(&mutex);
        printf("Consumer: %c \n", buffer[i]);
        pthread_mutex_unlock(&mutex);
        sem_post(&sem1);
    }
}

void *producer(void *arg)
{
    int i;
    for (i = 0; i < N; i++)
    {
        sem_wait(&sem1);
        pthread_mutex_lock(&mutex);
        buffer[i] = '1' + i;
        printf("Producer: %c \n", buffer[i]);
        pthread_mutex_unlock(&mutex); 
        sem_post(&sem2);
    }
}



int main()
{
    pthread_t id1, id2;
     sem_init(&sem2, 0, 1);
    sem_init(&sem1, 0, N);
   
    pthread_mutex_init(&mutex, NULL);
    pthread_create(&id1, NULL, producer, NULL);
    pthread_create(&id2, NULL, consumer, NULL);
    pthread_join(id1, NULL);
    pthread_join(id2, NULL);
    sem_destroy(&sem1);
    sem_destroy(&sem2);
    pthread_mutex_destroy(&mutex);
    return 0;
}

